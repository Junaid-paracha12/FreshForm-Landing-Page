import React from "react";

const Orders = ({ order: { title, text, btn, content } }) => {
  return (
    <>
      <div className="my-11">
        <div className="app-container">
          <h1 className="text-2xl lg:text-xl md:text-lg md:text-center font-bold">
            {title}
          </h1>
          <div className="flex justify-between md:flex-col  md:text-center py-2">
            <p className="text-sm md:text-xs text-slate-600 md:py-3 ">{text}</p>
            <div>
              <button
                type="button"
                className="button-theme bg-black text-white text-sm "
              >
                {btn}
              </button>
            </div>
          </div>
          <div className="flex items-center gap-7  overflow-x-scroll scroll-smooth scroll-hidden w-full mt-3">
            {content?.map((v, i) => (
              <div key={i} className=" border-t-2 p-2 w-full ">
                <h1 className="text-slate-600 w-96">{v.step}</h1>
                <h1 className="text-2xl md:text-xl sm:text-lg font-bold ">
                  {v.title}
                </h1>
                <p className="text-sm">{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Orders;
