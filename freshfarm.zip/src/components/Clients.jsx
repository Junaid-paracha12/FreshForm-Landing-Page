import React from "react";

const Clients = ({ client: { title, content } }) => {
  return (
    <>
      <div className="app-container mt-11">
        <div className="text-center py-5">
          <h1 className="text-3xl lg:text-2xl md:text-xl sm:text-lg xsm:text-base   ">
            {title}
          </h1>
        </div>
        <div className="grid grid-cols-3 lg:grid-cols-2 md:grid-cols-1 gap-6 sm:text-center ">
          {content?.map((v, i) => (
            <div key={i} className=" border-t-2">
              <h1 className="text-slate-600 mt-3 md:text-sm">{v.title}</h1>
              <h1 className="text-3xl lg:text-2xl md:text-xl sm:text-lg font-bold py-2">
                {v.year}
              </h1>
              <p className="text-sm md:text-xs">{v.text}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Clients;
