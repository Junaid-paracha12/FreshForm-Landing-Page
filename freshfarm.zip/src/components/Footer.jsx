import React from "react";

const Footer = ({ footer: { title, list } }) => {
  return (
    <>
      <div className="bg-black h-[40vh] md:h-auto w-full relative">
        <div className="app-container py-5">
          <div className="flex items-center md:flex-col  md:items-start justify-between my-8 ">
            <h1 className="text-white text-xl font-semibold">{title}</h1>

            <ul className= "flex items-center flex-wrap gap-5 md:py-3">
              {list?.map((v, i) => (
                <li key={i} className="text-white text-xs">
                  {v.text}
                </li>
              ))}
            </ul>
          </div>

          <div className=" absolute bottom-2 w-[90%] border-t-2   ">
            <div className="border-slate-600 flex items-center flex-wrap justify-between">
            <p className="text-white text-xs">
              © 2023FreshFarm. All rights reserved.
            </p>
            <ul className="text-xs text-white flex items-center gap-3 md:py-2">
              <li>Policy service</li>
              <li>Terms of Service</li>
            </ul></div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Footer;
